-- questão 2:
-- Crie uma tabela chamada "pedidos_emprestimo" no sistema de gerenciamento
-- de banco de dados mySQL, com os seguintes campos:

-- ● id (chave primária)
-- ● nomecliente
-- ● livro
-- ● dataemprestimo

CREATE TABLE bdBiblioteca.pedidos_emprestimo (
	id int AUTO_INCREMENT primary key,
    nomecliente VARCHAR(100),
    livro VARCHAR(40),
    dataemprestimo VARCHAR(255)
    );

-- Crie um arquivo e coloque o código SQL da criação da tabela que será
-- anexado junto ao projeto.