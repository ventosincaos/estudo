<?php
include_once("../config/url.php");
include_once("../config/conexao.php");

$data = $_POST; // define as variaveis do formulario que usam POST  

if (!isset($_POST["bt_sub"])) {
    try {


        $nome = $data["nomecliente"];
        $sobrenome = $data["livro"];
        $cpf = $data["dataemprestimo"];

        $query = "INSERT INTO pedidos_emprestimo (nomecliente, livro, dataemprestimo) 
        VALUES (:nomecliente, :livro, :dataemprestimo)";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(":nomecliente", $nomecliente);
        $stmt->bindParam(":livro", $livro);
        $stmt->bindParam(":dataemprestimo", $dataemprestimo);
        $stmt->execute();


    } catch (PDOException $e) {
        $erro = $e->getMessage();
        echo $erro;
    }
    header("Location:" . $BASE_URL . "/../templetes/formularioPedidoDeEmprestimo.php");

}

if (!isset($_POST["bt_sub"])) {
    try {
        $nome = $_POST["nomecliente"];
        $cpf = $_POST["livro"];
        $dt_nasc = $_POST["dataemprestimo"];

        try {
            $sql = 'INSERT INTO `aluno`.`aluno` (`nome`,`cpf`,`dt_nasc`,`endereco`,`semestre`,`dt_inicio`,`curso`)  
               VALUES (:nome,:cpf,:dt_nasc,:endereco,:semestre,:dt_inicio,:curso);';


            $stmt = $PDO->prepare($sql);

            $stmt->bindParam(':nome', $nome);
            $stmt->bindParam(':cpf', $cpf);
            $stmt->bindParam(':dt_nasc', $dt_nasc);
            $stmt->bindParam(':endereco', $endereco);
            $stmt->bindParam(':semestre', $semestre);
            $stmt->bindParam(':dt_inicio', $dt_inicio);
            $stmt->bindParam(':curso', $curso);
            $stmt->execute();

            if ($stmt->rowCount() > 0) {
                header('Location: ../templates/formularioPedidoDeEmprestimo.php');
                exit();
            }
        } catch (PDOException $e) {
            echo 'Erro no banco de dados' . $e->getMessage();
        } catch (Exception $e) {
            echo 'Erro generico' . $e->getMessage();
        }
    }
}