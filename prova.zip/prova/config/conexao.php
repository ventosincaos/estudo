<?php
/* Implemente o arquivo chamado conexao.php com as regras de conexão
no banco de dados criado na questão 1 usando DTO. */

$host = "localhost:3306";
$dbname = "bdBiblioteca";
$user = "root";
$pass = "senac";
try {
    $conn = new PDO("mysql:host=$host; dbname=$dbname", $user, $pass);
    //ativa o modo de erros
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (PDOException $e) {
    $erro = $e->getMessage();
    echo $erro;
}