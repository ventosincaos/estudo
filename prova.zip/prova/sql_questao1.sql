-- questao 1: 
-- Crie o banco de dados no sistema de gerenciamento de banco de dados
-- mySQL chamado "bdBiblioteca".
-- Crie um arquivo e coloque o código SQL da criação do banco de dados
-- que será anexado junto ao projeto.


CREATE SCHEMA `bdBiblioteca` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci ;
use bdBiblioteca;

